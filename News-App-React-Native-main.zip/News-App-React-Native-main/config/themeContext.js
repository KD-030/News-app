import React, { createContext } from "react";

const themeContext = createContext({});

export default themeContext;